# Codespaces

TODO: welcome and introduction

# Overview

TODO: document devcontainer
TODO: reference extensions
TODO: use of dockercompose and services

# Terminal

TODO: link to vscode terminal

# Graphics and Simulations

TODO: vnc options
TODO: foxglove example
TODO: gazebo example with gzweb

# References

TODO: links to more info