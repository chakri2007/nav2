# nav2_msgs

The `nav2_msgs` package is a set of messages, services, and actions for the `Nav2` system. `Nav2` also makes use of the standard `nav_msgs`, where appropriate.
